﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using part1; 
using MyWpfApp; 


namespace MyWpfApp
{
    public partial class MainWindow : Window
    {
        private TaskManager taskManager = new TaskManager();
        // ChatBot core data & state
        private readonly Random chatRandom = new();
        private string chatUserName = "User";
        private string currentTopic = null;

        public MainWindow()
        {
            InitializeComponent();
           

            MainTabControl.SelectedIndex = 0; // Make ChatBot tab active

            ReminderPicker.SelectedDate = DateTime.Now;

            
            var logo = new logo_design();
            AsciiLogoBlock.Text = logo.GenerateAsciiLogo();
        }



        private void StartQuiz_Click(object sender, RoutedEventArgs e)
        {
            var quizWindow = new QuizWindow();
            bool? dialogResult = quizWindow.ShowDialog();

            if (dialogResult == true)
            {
                LogActivity($"Completed the quiz. Score: {quizWindow.Score} / {quizWindow.TotalQuestions}");

            }


        }

        private void AddTask_Click(object sender, RoutedEventArgs e)
        {
            var title = TitleBox.Text.Trim();
            var description = DescriptionBox.Text.Trim();
            var reminder = ReminderPicker.SelectedDate;

            if (string.IsNullOrEmpty(title))
            {
                MessageBox.Show("Please enter a task title.");
                return;
            }

            var task = new TaskItem
            {
                Title = title,
                Description = description,
                ReminderDate = reminder,
                IsCompleted = false
            };

            taskManager.AddTask(task);
            LogActivity($"Added task: {title}");
            RefreshTaskList();

            TitleBox.Clear();
            DescriptionBox.Clear();
            ReminderPicker.SelectedDate = DateTime.Now;
        }

        private void RefreshTaskList()
        {
            TaskListBox.Items.Clear();
            var tasks = taskManager.GetTasks();

            foreach (var task in tasks)
                TaskListBox.Items.Add(task);
        }

        private void CompleteTask_Click(object sender, RoutedEventArgs e)
        {
            int index = TaskListBox.SelectedIndex;
            if (index == -1)
            {
                MessageBox.Show("Select a task to complete.");
                return;
            }

            taskManager.MarkCompleted(index);
            LogActivity($"Marked task as completed: {TitleBox.Text}");
            RefreshTaskList();
        }

        private void DeleteTask_Click(object sender, RoutedEventArgs e)
        {
            int index = TaskListBox.SelectedIndex;
            if (index == -1)
            {
                MessageBox.Show("Select a task to delete.");
                return;
            }

            taskManager.DeleteTask(index);
            LogActivity($"Deleted a task.");
            RefreshTaskList();
        }

        private void LogActivity(string message)
        {
            string timestamp = DateTime.Now.ToString("HH:mm:ss");
            ActivityLogText.Text += $"[{timestamp}] {message}\n";
        }

        private readonly string[] questions = {
    "How are you?", "What can I ask you about?", "What’s your purpose?",
    "Password safety?", "Phishing?", "Safe browsing?"
};

        private readonly string[] responses = {
    "I'm doing well, thank you! How can I help you today?",
    "Ask me anything about cybersecurity: passwords, phishing, browsing safety, or tasks and quizzes.",
    "I'm here to assist you with security tips and help you manage tasks or quizzes.",
    "Use strong, unique passwords and enable two-factor authentication.",
    "Phishing is tricking users via fraudulent messages—always check the source!",
    "Safe browsing means HTTPS, checking URLs, and avoiding unknown downloads."
};

        private readonly Dictionary<string, List<string>> keywordResponses = new(StringComparer.OrdinalIgnoreCase) {
    { "password", new() {
            "Always use a strong, unique password.",
            "Consider using a password manager for secure storage.",
            "Long passphrases are often easier to remember and more secure."
        }
    },
    { "phishing", new() {
            "Phishing tricks users into giving credentials—be alert for suspicious emails.",
            "Never click links in unsolicited messages.",
            "Verify the sender before acting on any request."
        }
    },
    { "privacy", new() {
            "Review privacy settings regularly on social media.",
            "Be cautious about sharing personal information online.",
            "Use privacy-focused browsers or VPNs when needed."
        }
    }
};

        private readonly string[] confusionKeywords = {
    "more", "details", "explain", "don't understand", "unclear", "help", "confused"
};

        // Chat UI event handlers
        private void SendChatButton_Click(object sender, RoutedEventArgs e) => HandleChatInput();

        private void UserChatInput_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter) HandleChatInput();
        }

        private void HandleChatInput()
        {
            string input = UserChatInput.Text.Trim();
            if (string.IsNullOrEmpty(input)) return;

            AppendChat($"You: {input}");
            string botResponse = GenerateBotResponse(input);
            AppendChat($"Bot: {botResponse}");
            UserChatInput.Clear();

            ChatScroll.ScrollToEnd();
        }

        private void AppendChat(string message)
        {
            ChatHistoryText.Text += $"{message}\n";
        }

        private string GenerateBotResponse(string input)
        {
            string lower = input.ToLower();

            // Greetings & farewells
            if (lower.Contains("hello") || lower.Contains("hi")) { chatUserName = input.Split(' ').Last(); return $"Hello {chatUserName}! 😊"; }
            if (lower.Contains("bye")) return "Goodbye! Stay safe online! 👋";

            // Predefined Q&A
            for (int i = 0; i < questions.Length; i++)
                if (lower.Contains(questions[i].ToLower()))
                    return responses[i];

            // Keyword-based random answers
            foreach (var kv in keywordResponses)
                if (lower.Contains(kv.Key))
                    return kv.Value[chatRandom.Next(kv.Value.Count)];

            // Confusion Check (follow up)
            if (currentTopic != null && confusionKeywords.Any(k => lower.Contains(k)))
                return $"Tell me more about {currentTopic}? I can explain further.";

            // Task, Quiz, Log Suggestions
            if (lower.Contains("task")) return "Want to manage tasks? Switch to the Task Manager tab.";
            if (lower.Contains("quiz")) return "Ready for a quiz? Head to the Quiz tab!";
            if (lower.Contains("log")) return "Your recent actions are visible in the Activity Log tab.";

            if (lower.Contains("logo") || lower.Contains("ascii art"))
            {
                var logo = new logo_design();
                return logo.GenerateAsciiLogo();
            }

            // Default fallback
            return "I'm not sure I understand. Try asking about phishing, passwords, or quizzes.";

           

        }

    }
}
