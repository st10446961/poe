﻿using System;
using System.Collections.Generic;

namespace MyWpfApp
{
    
        public class TaskManager
        {
            private List<TaskItem> tasks = new List<TaskItem>();

            public void AddTask(TaskItem task) => tasks.Add(task);
            public void DeleteTask(int index)
            {
                if (index >= 0 && index < tasks.Count)
                    tasks.RemoveAt(index);
            }

            public void MarkCompleted(int index)
            {
                if (index >= 0 && index < tasks.Count)
                    tasks[index].IsCompleted = true;
            }

            public List<TaskItem> GetTasks() => tasks;
        }
    }
