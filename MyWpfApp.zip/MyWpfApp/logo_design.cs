﻿using System;
using System.Drawing;   // <-- Required
using System.IO;        // <-- Required
using System.Text;

namespace part1
{
    internal class logo_design
    {
        public string GenerateAsciiLogo()
        {
            StringBuilder asciiArt = new StringBuilder();

            // Get full location of the project
            string full_location = AppDomain.CurrentDomain.BaseDirectory;

            // Adjust the path to work correctly depending on output path
            string new_location = full_location.Replace("bin\\Debug\\net6.0-windows\\", ""); // Change if using a different target
            string full_path = Path.Combine(new_location, "logo20.jpg");

            if (!File.Exists(full_path))
                return "⚠️ Logo image not found at: " + full_path;

            var image = new Bitmap(full_path);
            image = new Bitmap(image, new Size(100, 40));  // Resize image for ASCII

            for (int y = 0; y < image.Height; y++)
            {
                for (int x = 0; x < image.Width; x++)
                {
                    Color pixelColor = image.GetPixel(x, y);
                    int gray = (pixelColor.R + pixelColor.G + pixelColor.B) / 3;

                    char asciiChar = gray > 200 ? '.' :
                                     gray > 150 ? '*' :
                                     gray > 100 ? 'o' :
                                     gray > 50 ? '#' : '@';

                    asciiArt.Append(asciiChar);
                }
                asciiArt.AppendLine();
            }

            return asciiArt.ToString();
        }
    }
}
