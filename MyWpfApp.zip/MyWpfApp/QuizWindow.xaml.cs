﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace MyWpfApp
{
    /// <summary>
    /// Interaction logic for QuizWindow.xaml
    /// </summary>
    public partial class QuizWindow : Window
    {
        public int Score { get; private set; }
        public int TotalQuestions { get; private set; }



        private int currentQuestionIndex = 0;
        private int score = 0;

        private readonly List<(string Question, List<string> Options, string Answer, string Explanation)> questions
    = new()
{
    ("Which of the following is a sign of a phishing email?",
        new List<string>{ "A) An unexpected attachment", "B) Personalized greeting", "C) Comes from your boss", "D) Sent from your own email" },
        "A",
        "Phishing emails often contain unexpected attachments to trick users into downloading malware."),

    ("True or False: It's safe to reuse the same password across multiple sites.",
        new List<string>{ "True", "False" },
        "False",
        "Reusing passwords is risky—if one account is compromised, others can be too."),

    ("Which is the most secure password?",
        new List<string>{ "A) Password123", "B) John2020", "C) @D9#h!Zq", "D) abcdefgh" },
        "C",
        "Strong passwords use random characters, numbers, and symbols."),

    ("True or False: HTTPS means the website is always 100% safe.",
        new List<string>{ "True", "False" },
        "False",
        "HTTPS encrypts traffic, but a malicious site can still use it."),

    ("What is social engineering?",
        new List<string>{ "A) A programming language", "B) Manipulating people to reveal confidential info", "C) Software update", "D) A firewall feature" },
        "B",
        "Social engineering tricks people into giving away sensitive info through trust or manipulation."),

    ("What is the purpose of a firewall?",
        new List<string>{ "A) Speed up your computer", "B) Block unauthorized access", "C) Store passwords", "D) Detect viruses" },
        "B",
        "A firewall monitors and controls network traffic to block unauthorized access."),

    ("Which of the following is a strong security practice?",
        new List<string>{ "A) Clicking pop-up ads", "B) Sharing your password", "C) Using multi-factor authentication", "D) Writing passwords on sticky notes" },
        "C",
        "Multi-factor authentication adds an extra layer of protection beyond just a password."),

    ("True or False: Antivirus software should only be run once a month.",
        new List<string>{ "True", "False" },
        "False",
        "Antivirus software should run regularly and in real-time to catch threats immediately."),

    ("What does a VPN do?",
        new List<string>{ "A) Speeds up browsing", "B) Encrypts your internet traffic", "C) Blocks spam emails", "D) Updates your software" },
        "B",
        "A VPN encrypts your traffic and hides your IP address, helping protect your privacy."),

    ("Which of these is a common goal of ransomware?",
        new List<string>{ "A) Speed up your system", "B) Help you recover lost files", "C) Encrypt data and demand payment", "D) Provide software updates" },
        "C",
        "Ransomware encrypts files and demands payment for the decryption key.")
};


        public QuizWindow()
        {
            InitializeComponent();
            MessageBox.Show($"Loaded {questions.Count} questions");
            LoadQuestion();
        }

        private void LoadQuestion()
        {
            if (currentQuestionIndex < questions.Count)
            {
                var q = questions[currentQuestionIndex];
                QuestionText.Text = $"Q{currentQuestionIndex + 1}: {q.Question}";

                OptionsList.Items.Clear();
                foreach (var option in q.Options)
                    OptionsList.Items.Add(option);

                FeedbackText.Text = "";
            }
            else
            {
                QuestionText.Text = $"Quiz finished! You scored {score} out of {questions.Count}.";
                OptionsList.Visibility = Visibility.Collapsed;

                // 🎯 Add final feedback based on score
                if (score >= 4)
                {
                    FeedbackText.Foreground = System.Windows.Media.Brushes.Green;
                    FeedbackText.Text = "🎉 Great job! You're a cybersecurity pro!";
                }
                else if (score >= 2)
                {
                    FeedbackText.Foreground = System.Windows.Media.Brushes.Orange;
                    FeedbackText.Text = "👍 Good effort! Keep practicing!";
                }
                else
                {
                    FeedbackText.Foreground = System.Windows.Media.Brushes.Red;
                    FeedbackText.Text = "📘 Keep learning to stay safe online!";
                }
            }
        }

        private void SubmitAnswer_Click(object sender, RoutedEventArgs e)
        {
            if (OptionsList.SelectedItem == null)
            {
                MessageBox.Show("Please select an answer.");
                return;
            }

            var selectedOption = OptionsList.SelectedItem.ToString();
            var correctAnswer = questions[currentQuestionIndex].Answer;

            if (selectedOption.StartsWith(correctAnswer))
            {
                score++;
                FeedbackText.Foreground = Brushes.Green;
                FeedbackText.Text = "✅ Correct!";
            }
            else
            {
                FeedbackText.Foreground = Brushes.Red;
                FeedbackText.Text = $"❌ Incorrect! Correct answer: {correctAnswer}\n{questions[currentQuestionIndex].Explanation}";
            }

            currentQuestionIndex++;

            // Add a short delay before moving to next question or finishing
            Dispatcher.InvokeAsync(async () =>
            {
                await Task.Delay(1000);

                if (currentQuestionIndex >= questions.Count)
                {
                    this.Score = score;
                    this.TotalQuestions = questions.Count;

                    MessageBox.Show($"Quiz completed!\nYour Score: {score} / {questions.Count}", "Quiz Result");

                    this.DialogResult = true; // This is how MainWindow knows quiz ended
                    this.Close();
                }
                else
                {
                    LoadQuestion();
                }
            });
        }
    }
}  


