﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyWpfApp
{
   
        public class TaskItem
        {
            public string Title { get; set; }
            public string Description { get; set; }
            public DateTime? ReminderDate { get; set; }
            public bool IsCompleted { get; set; }

            public override string ToString()
            {
                string status = IsCompleted ? "[Completed]" : "[Pending]";
                string reminder = ReminderDate.HasValue ? ReminderDate.Value.ToString("yyyy-MM-dd HH:mm") : "No reminder";
                return $"{status} {Title} - {reminder}";
            }
        }
    }

